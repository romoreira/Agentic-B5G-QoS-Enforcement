// SPDX-License-Identifier: Apache-2.0
// Copyright 2022-present Open Networking Foundation

package commands

import (
	"context"
	"fmt"
	"strconv"
	"strings"

	pb "github.com/omec-project/pfcpsim/api"
	"github.com/omec-project/pfcpsim/logger"
	"github.com/urfave/cli/v3"
)

// parseUint64CSV parses a CSV of unsigned integers (e.g. "50000,300000,600000").
// Returns nil on empty input.
func parseUint64CSV(s string) ([]uint64, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return nil, nil
	}
	parts := strings.Split(s, ",")
	out := make([]uint64, 0, len(parts))
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p == "" {
			continue
		}
		v, err := strconv.ParseUint(p, 10, 64)
		if err != nil {
			return nil, fmt.Errorf("invalid uint64 value %q: %w", p, err)
		}
		out = append(out, v)
	}
	return out, nil
}

// getCommonFlags returns the common flags used by session commands
func getCommonFlags() []cli.Flag {
	return []cli.Flag{
		&cli.IntFlag{
			Name:    "count",
			Aliases: []string{"c"},
			Value:   1,
			Usage:   "The number of sessions to create",
		},
		&cli.IntFlag{
			Name:    "baseID",
			Aliases: []string{"i"},
			Value:   1,
			Usage:   "The base ID to use",
		},
		&cli.StringFlag{
			Name:    "ue-pool",
			Aliases: []string{"u"},
			Value:   "17.0.0.0/24",
			Usage:   "The UE pool address",
		},
		&cli.StringFlag{
			Name:    "gnb-addr",
			Aliases: []string{"g"},
			Usage:   "The gNB address",
		},
		&cli.StringSliceFlag{
			Name:    "app-filter",
			Aliases: []string{"a"},
			Value:   []string{"ip:any:any:allow:100"},
			Usage:   "Specify an application filter. Format: '{ip|udp|tcp}:{IPv4 Prefix|any}:{lower-upper|any}:{allow|deny}:{precedence}'",
		},
		&cli.UintFlag{
			Name:    "qfi",
			Aliases: []string{"q"},
			Usage:   "The QFI value for QERs. Max value 64",
		},
		// MBR flags accept a CSV of kbps values, one per session.
		&cli.StringFlag{
			Name:  "session-mbr-uplink",
			Usage: "Per-session uplink session-level MBR in kbps, CSV (e.g. '50000,300000,600000')",
		},
		&cli.StringFlag{
			Name:  "session-mbr-downlink",
			Usage: "Per-session downlink session-level MBR in kbps, CSV",
		},
		&cli.StringFlag{
			Name:  "app-mbr-uplink",
			Usage: "Per-session uplink app-level MBR in kbps, CSV",
		},
		&cli.StringFlag{
			Name:  "app-mbr-downlink",
			Usage: "Per-session downlink app-level MBR in kbps, CSV",
		},
	}
}

// validateCommonArgs validates common arguments
func validateCommonArgs(c *cli.Command) {
	baseID := c.Int("baseID")
	count := c.Int("count")

	if baseID <= 0 {
		logger.PfcpsimLog.Fatalln("baseID cannot be 0 or a negative number")
	}

	if count <= 0 {
		logger.PfcpsimLog.Fatalln("count cannot be 0 or a negative number")
	}
}

// parseAllMBR parses the four MBR flags or fatals on invalid input.
func parseAllMBR(c *cli.Command) (sUL, sDL, aUL, aDL []uint64) {
	var err error
	if sUL, err = parseUint64CSV(c.String("session-mbr-uplink")); err != nil {
		logger.PfcpsimLog.Fatalf("invalid --session-mbr-uplink: %v", err)
	}
	if sDL, err = parseUint64CSV(c.String("session-mbr-downlink")); err != nil {
		logger.PfcpsimLog.Fatalf("invalid --session-mbr-downlink: %v", err)
	}
	if aUL, err = parseUint64CSV(c.String("app-mbr-uplink")); err != nil {
		logger.PfcpsimLog.Fatalf("invalid --app-mbr-uplink: %v", err)
	}
	if aDL, err = parseUint64CSV(c.String("app-mbr-downlink")); err != nil {
		logger.PfcpsimLog.Fatalf("invalid --app-mbr-downlink: %v", err)
	}
	return
}

func GetSessionCommands() *cli.Command {
	return &cli.Command{
		Name:  "session",
		Usage: "Handle sessions",
		Commands: []*cli.Command{
			{
				Name:  "create",
				Usage: "Create sessions",
				Flags: getCommonFlags(),
				Action: func(ctx context.Context, c *cli.Command) error {
					return sessionCreateAction(ctx, c)
				},
			},
			{
				Name:  "modify",
				Usage: "Modify sessions",
				Flags: append(getCommonFlags(), []cli.Flag{
					&cli.BoolFlag{
						Name:    "buffer",
						Aliases: []string{"b"},
						Usage:   "If set, downlink FARs will have the buffer flag set to true",
					},
					&cli.BoolFlag{
						Name:    "notifycp",
						Aliases: []string{"n"},
						Usage:   "Set true to have downlink FARs notify CP",
					},
				}...),
				Action: func(ctx context.Context, c *cli.Command) error {
					return sessionModifyAction(ctx, c)
				},
			},
			{
				Name:  "delete",
				Usage: "Delete sessions",
				Flags: getCommonFlags(),
				Action: func(ctx context.Context, c *cli.Command) error {
					return sessionDeleteAction(ctx, c)
				},
			},
		},
	}
}

func sessionCreateAction(ctx context.Context, c *cli.Command) error {
	qfi := c.Uint("qfi")
	if qfi > 64 {
		logger.PfcpsimLog.Fatalf("qfi cannot be greater than 64. Provided qfi: %v", qfi)
	}

	client := connect()
	defer disconnect()

	validateCommonArgs(c)
	sUL, sDL, aUL, aDL := parseAllMBR(c)

	res, err := client.CreateSession(ctx, &pb.CreateSessionRequest{
		Count:              int32(c.Int("count")),
		BaseID:             int32(c.Int("baseID")),
		NodeBAddress:       c.String("gnb-addr"),
		UeAddressPool:      c.String("ue-pool"),
		AppFilters:         c.StringSlice("app-filter"),
		Qfi:                int32(qfi),
		SessionMbrUplink:   sUL,
		SessionMbrDownlink: sDL,
		AppMbrUplink:       aUL,
		AppMbrDownlink:     aDL,
	})
	if err != nil {
		logger.PfcpsimLog.Fatalf("error while creating sessions: %v", err)
	}

	logger.PfcpsimLog.Infoln(res.Message)
	return nil
}

func sessionModifyAction(ctx context.Context, c *cli.Command) error {
	client := connect()
	defer disconnect()

	validateCommonArgs(c)
	sUL, sDL, aUL, aDL := parseAllMBR(c)

	res, err := client.ModifySession(ctx, &pb.ModifySessionRequest{
		Count:              int32(c.Int("count")),
		BaseID:             int32(c.Int("baseID")),
		NodeBAddress:       c.String("gnb-addr"),
		UeAddressPool:      c.String("ue-pool"),
		BufferFlag:         c.Bool("buffer"),
		NotifyCPFlag:       c.Bool("notifycp"),
		AppFilters:         c.StringSlice("app-filter"),
		SessionMbrUplink:   sUL,
		SessionMbrDownlink: sDL,
		AppMbrUplink:       aUL,
		AppMbrDownlink:     aDL,
	})
	if err != nil {
		logger.PfcpsimLog.Fatalf("error while modifying sessions: %v", err)
	}

	logger.PfcpsimLog.Infoln(res.Message)
	return nil
}

func sessionDeleteAction(ctx context.Context, c *cli.Command) error {
	client := connect()
	defer disconnect()

	validateCommonArgs(c)

	res, err := client.DeleteSession(ctx, &pb.DeleteSessionRequest{
		Count:  int32(c.Int("count")),
		BaseID: int32(c.Int("baseID")),
	})
	if err != nil {
		logger.PfcpsimLog.Fatalf("error while deleting sessions: %v", err)
	}

	logger.PfcpsimLog.Infoln(res.Message)
	return nil
}
